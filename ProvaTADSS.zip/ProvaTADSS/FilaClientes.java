// Recurso compartilhado (Monitor)
public class FilaClientes {
    private Cliente[] fila;
    private int qtde = 0;

    public FilaClientes(int tamanho) {
        fila = new Cliente[tamanho];
    }

    // synchronized pra evitar condicao de corrida
    public synchronized void addCliente(Cliente c) {
        while (qtde == fila.length) {
            try {
                wait(); // trava se a fila encher
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        fila[qtde] = c;
        qtde++;
        notifyAll(); // avisa que chegou cliente novo
    }

    public synchronized Cliente removeCliente() {
        Cliente c = null;

        if (qtde == 0) {
            try {
                wait(2000); // timeout de 2s se a fila tiver vazia
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (qtde > 0) {
            c = fila[0]; 

            // anda com a fila (fifo)
            for (int i = 0; i < qtde - 1; i++) {
                fila[i] = fila[i + 1];
            }

            fila[qtde - 1] = null;
            qtde--;
            notifyAll(); // libera quem tava esperando pra adicionar
        }

        return c;
    }

    public synchronized boolean temCliente() {
        return qtde > 0;
    }

    public int getQtde() {
        return qtde;
    }
}