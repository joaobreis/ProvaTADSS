public class FilaClientes {
    private Cliente[] fila;
    private int qtde = 0;

    public FilaClientes(int tamanho) {
        fila = new Cliente[tamanho];
    }

    public synchronized void addCliente(Cliente c) {
        while (qtde == fila.length) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        fila[qtde] = c;
        qtde++;
        notifyAll();
    }

    public synchronized Cliente removeCliente() {
        Cliente c = null;

        if (qtde == 0) {
            try {
                wait(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (qtde > 0) {
            c = fila[0];

            for (int i = 0; i < qtde - 1; i++) {
                fila[i] = fila[i + 1];
            }

            fila[qtde - 1] = null;
            qtde--;
            notifyAll();
        }

        return c;
    }

    public synchronized boolean temCliente() {
        return qtde > 0;
    }

    public int getQtde() {
        return qtde;
    }

    public String toString() {
        String s = "Fila: ";

        for (int i = 0; i < qtde; i++) {
            s = s + fila[i] + " ";
        }

        return s;
    }
}