public enum Estado {
    NA_FILA,
    NO_ATENDIMENTO,
    SAIU
}