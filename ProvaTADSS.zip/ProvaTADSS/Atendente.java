// Thread que faz o papel do funcionario
public class Atendente implements Runnable {
    private FilaClientes fila;
    private Estatisticas estatisticas;
    private GeradorClientes gerador;
    private long livre; // guarda quando o atendente fica livre de novo

    public Atendente(FilaClientes fila, Estatisticas estatisticas, GeradorClientes gerador) {
        this.fila = fila;
        this.estatisticas = estatisticas;
        this.gerador = gerador;
        this.livre = 0;
    }

    public void run() {
        Cliente cliente = null;

        do {
            // puxa o proximo cliente da fila
            cliente = fila.removeCliente();

            if (cliente != null) {
                cliente.setEstado(Estado.NO_ATENDIMENTO);

                // ve quem chegou por ultimo: o cliente ou o atendente (se tava ocioso)
                long inicio;
                if (cliente.getChegada() > livre) {
                    inicio = cliente.getChegada();
                } else {
                    inicio = livre;
                }

                cliente.setInicioAtendimento(inicio);

                long fim = inicio + cliente.getTempoAtendimento();
                cliente.setFimAtendimento(fim);
                livre = fim;

                cliente.setEstado(Estado.SAIU);

                // printa no console pra ver as threads rodando
                System.out.printf("%s atendeu cliente %d | espera=%d | atendimento=%d\n",
                        Thread.currentThread().getName(),
                        cliente.getId(),
                        cliente.getTempoEspera(),
                        cliente.getTempoAtendimento());

                estatisticas.addClienteAtendido(cliente);

                // da um yield pra nao travar a cpu numa thread so
                Thread.yield();
            }
        } while (!gerador.terminou() || fila.temCliente());

        System.out.printf("%s terminou\n", Thread.currentThread().getName());
    }
}