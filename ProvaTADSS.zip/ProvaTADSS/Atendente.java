public class Atendente implements Runnable {
    private FilaClientes fila;
    private Estatisticas estatisticas;
    private GeradorClientes gerador;
    private long livre;

    public Atendente(FilaClientes fila, Estatisticas estatisticas, GeradorClientes gerador) {
        this.fila = fila;
        this.estatisticas = estatisticas;
        this.gerador = gerador;
        this.livre = 0;
    }

    public void run() {
        Cliente cliente = null;

        do {
            cliente = fila.removeCliente();

            if (cliente != null) {
                cliente.setEstado(Estado.NO_ATENDIMENTO);

                long inicio;
                if (cliente.getChegada() > livre) {
                    inicio = cliente.getChegada();
                } else {
                    inicio = livre;
                }

                cliente.setInicioAtendimento(inicio);

                long fim = inicio + cliente.getTempoAtendimento();
                cliente.setFimAtendimento(fim);

                livre = fim;

                cliente.setEstado(Estado.SAIU);

                System.out.printf("%s atendeu cliente %d | espera=%d | atendimento=%d\n",
                        Thread.currentThread().getName(),
                        cliente.getId(),
                        cliente.getTempoEspera(),
                        cliente.getTempoAtendimento());

                estatisticas.addClienteAtendido(cliente);

                Thread.yield();
            }
        } while (!gerador.terminou() || fila.temCliente());

        System.out.printf("%s terminou\n", Thread.currentThread().getName());
    }
}