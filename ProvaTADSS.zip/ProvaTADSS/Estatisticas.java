public class Estatisticas {
    private Cliente[] clientes;
    private int qtde;

    public Estatisticas(int tamanho) {
        clientes = new Cliente[tamanho];
    }

    public synchronized void addClienteAtendido(Cliente c) {
        clientes[qtde] = c;
        qtde++;
    }

    public int getQtdeAtendidos() {
        return qtde;
    }

    public double getTempoMedioEspera() {
        long soma = 0;

        if (qtde == 0) {
            return 0;
        }

        for (int i = 0; i < qtde; i++) {
            soma = soma + clientes[i].getTempoEspera();
        }

        return (double) soma / qtde;
    }

    public long getTempoMaximoEspera() {
        long maior = 0;

        for (int i = 0; i < qtde; i++) {
            if (clientes[i].getTempoEspera() > maior) {
                maior = clientes[i].getTempoEspera();
            }
        }

        return maior;
    }

    public double getTempoMedioAtendimento() {
        long soma = 0;

        if (qtde == 0) {
            return 0;
        }

        for (int i = 0; i < qtde; i++) {
            soma = soma + clientes[i].getTempoAtendimento();
        }

        return (double) soma / qtde;
    }

    public long getTempoMaximoAtendimento() {
        long maior = 0;

        for (int i = 0; i < qtde; i++) {
            if (clientes[i].getTempoAtendimento() > maior) {
                maior = clientes[i].getTempoAtendimento();
            }
        }

        return maior;
    }

    public double getTempoMedioSistema() {
        long soma = 0;

        if (qtde == 0) {
            return 0;
        }

        for (int i = 0; i < qtde; i++) {
            soma = soma + clientes[i].getTempoTotalSistema();
        }

        return (double) soma / qtde;
    }
}