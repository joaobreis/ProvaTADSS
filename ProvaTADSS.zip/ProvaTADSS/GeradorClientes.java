import java.util.Random;

public class GeradorClientes implements Runnable {
    private FilaClientes fila;
    private int total;
    private boolean terminou = false;

    public GeradorClientes(FilaClientes fila, int total) {
        this.fila = fila;
        this.total = total;
    }

    public void run() {
        Random r = new Random();
        long tempo = 0;

        for (int i = 1; i <= total; i++) {
            // chegada entre 5 e 50s
            tempo = tempo + (r.nextInt(46) + 5);

            // atendimento entre 30 e 120s
            Cliente c = new Cliente(i, Estado.NA_FILA, tempo, r.nextInt(91) + 30);
            fila.addCliente(c);

            System.out.printf("%s gerou cliente %d no tempo %d\n",
                    Thread.currentThread().getName(),
                    c.getId(),
                    tempo);
        }

        terminou = true;
        System.out.printf("%s terminou\n", Thread.currentThread().getName());
    }

    public boolean terminou() {
        return terminou;
    }
}