        // classe que guarda os dados de cada cliente
public class Cliente {
    private int id;
    private Estado estado;
    private long chegada;
    private long inicioAtendimento;
    private long fimAtendimento;
    private long tempoAtendimento;

 // cria o cliente ja com os tempos sorteados no gerador
    public Cliente(int id, Estado estado, long chegada, long tempoAtendimento) {
        this.id = id;
        this.estado = estado;
        this.chegada = chegada;
        this.tempoAtendimento = tempoAtendimento;
    }

    public int getId() {
        return id;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public long getChegada() {
        return chegada;
    }

    public long getInicioAtendimento() {
        return inicioAtendimento;
    }

    public void setInicioAtendimento(long inicioAtendimento) {
        this.inicioAtendimento = inicioAtendimento;
    }

    public long getFimAtendimento() {
        return fimAtendimento;
    }

    public void setFimAtendimento(long fimAtendimento) {
        this.fimAtendimento = fimAtendimento;
    }

    public long getTempoAtendimento() {
        return tempoAtendimento;
    }

    // calcula quanto tempo ficou parado na fila
    public long getTempoEspera() {
        return inicioAtendimento - chegada;
    }

    // calcula o tempo total (fila + atendimento)
    public long getTempoTotalSistema() {
        return fimAtendimento - chegada;
    }

    public String toString() {
        return id + ":" + estado;
    }
}