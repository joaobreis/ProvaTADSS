public class SimulacaoBanco {
    public static void main(String[] args) throws Exception {
        int totalClientes = 300;

        for (int n = 1; n <= 10; n++) {
            System.out.println("\nSimulacao com " + n + " atendente(s)");

            FilaClientes fila = new FilaClientes(totalClientes);
            Estatisticas estatisticas = new Estatisticas(totalClientes);
            GeradorClientes gerador = new GeradorClientes(fila, totalClientes);

            Thread tg = new Thread(gerador, "Gerador");
            tg.start();

            Thread[] atendentes = new Thread[n];
            for (int i = 0; i < n; i++) {
                Atendente atendente = new Atendente(fila, estatisticas, gerador);
                atendentes[i] = new Thread(atendente, "Atendente-" + (i + 1));
                atendentes[i].start();
            }

            tg.join();

            for (int i = 0; i < n; i++) {
                atendentes[i].join();
            }

            System.out.println("Resultados:");
            System.out.println("Clientes atendidos: " + estatisticas.getQtdeAtendidos());
            System.out.println("Tempo medio de espera: " + estatisticas.getTempoMedioEspera() + " segundos");
            System.out.println("Tempo maximo de espera: " + estatisticas.getTempoMaximoEspera() + " segundos");
            System.out.println("Tempo medio de atendimento: " + estatisticas.getTempoMedioAtendimento() + " segundos");
            System.out.println("Tempo maximo de atendimento: " + estatisticas.getTempoMaximoAtendimento() + " segundos");
            System.out.println("Tempo medio no sistema: " + estatisticas.getTempoMedioSistema() + " segundos");

            if (estatisticas.getTempoMedioEspera() <= 120) {
                System.out.println("Meta atendida.");
                break;
            } else {
                System.out.println("Meta nao atendida.");
            }
        }
    }
}